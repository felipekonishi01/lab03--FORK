#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();  

    if (pid < 0) {  
        perror("Erro ao criar processo");
        return 1;
    }

    if (pid == 0) { 
        printf("Processo Filho: PID = %d\n", getpid());

        //substitui o processo filho pelo programa "ls"
        execlp("ls", "ls", NULL);

        //tratamento de erro
        perror("Erro ao executar ls");
        return 1;
    } else { //fork pai
        printf("Processo Pai: PID do Pai = %d, PID do Filho = %d\n", getpid(), pid);

        wait(NULL);  //espera fork filho terminar

        printf("Processo Pai: O processo filho terminou.\n");
    }

    return 0;
}
